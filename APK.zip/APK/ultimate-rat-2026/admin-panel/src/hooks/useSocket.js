import { useEffect } from 'react';
import { useDeviceStore } from '../store/deviceStore';

export const useSocket = () => {
  const { initSocket, socket, isConnected } = useDeviceStore();

  useEffect(() => {
    if (!socket) {
      initSocket();
    }

    return () => {
      if (socket) {
        socket.disconnect();
      }
    };
  }, []);

  return { socket, isConnected };
};