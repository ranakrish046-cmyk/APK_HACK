import React, { useState } from 'react';
import { useDeviceStore } from '../../store/deviceStore';
import { useQuery } from '@tanstack/react-query';
import axios from 'axios';
import { Phone, PhoneCall, PhoneOff, Plus, Trash2 } from 'lucide-react';

const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:3000';

export default function Calls() {
  const { selectedDevice, sendCommand } = useDeviceStore();
  const [filter, setFilter] = useState('all');
  const [newCall, setNewCall] = useState('');

  const { data: callLogs = [] } = useQuery({
    queryKey: ['calls', selectedDevice?.sessionId, filter],
    queryFn: async () => {
      const type = filter === 'all' ? undefined : filter;
      const res = await axios.get(
        `${API_URL}/api/devices/${selectedDevice.sessionId}/calls?type=${type}`,
        { headers: { Authorization: `Bearer ${localStorage.getItem('authToken')}` } }
      );
      return res.data;
    },
    enabled: !!selectedDevice,
  });

  const handleMakeCall = () => {
    if (!selectedDevice || !newCall) return;
    sendCommand(selectedDevice.sessionId, 'call:make', { number: newCall });
    setNewCall('');
  };

  const getCallIcon = (type) => {
    switch (type) {
      case 'incoming': return <Phone className="w-4 h-4 text-success" />;
      case 'outgoing': return <PhoneCall className="w-4 h-4 text-primary" />;
      case 'missed': return <PhoneOff className="w-4 h-4 text-error" />;
      default: return <Phone className="w-4 h-4" />;
    }
  };

  return (
    <div className="p-6 space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-text mb-1">📞 Call Logs</h1>
        <p className="text-textMuted">View call history and make calls remotely</p>
      </div>

      {!selectedDevice ? (
        <div className="card text-center py-12">
          <Phone className="w-16 h-16 text-textMuted mx-auto mb-4" />
          <p className="text-textMuted">Select a device to access calls</p>
        </div>
      ) : (
        <>
          <div className="card">
            <h3 className="text-lg font-semibold text-text mb-4">Make Call</h3>
            <div className="flex gap-3">
              <input
                type="tel"
                placeholder="Phone number"
                value={newCall}
                onChange={(e) => setNewCall(e.target.value)}
                className="input-field flex-1"
              />
              <button onClick={handleMakeCall} className="btn-primary flex items-center gap-2">
                <Plus className="w-4 h-4" /> Call
              </button>
            </div>
          </div>

          <div className="card">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-text">Call Logs ({callLogs.length})</h3>
              <select value={filter} onChange={(e) => setFilter(e.target.value)} className="input-field">
                <option value="all">All</option>
                <option value="incoming">Incoming</option>
                <option value="outgoing">Outgoing</option>
                <option value="missed">Missed</option>
              </select>
            </div>
            <div className="space-y-2">
              {callLogs.length === 0 ? (
                <p className="text-textMuted text-center py-8">No call logs found</p>
              ) : (
                callLogs.slice(0, 50).map((call) => (
                  <div key={call._id} className="flex items-center justify-between p-3 bg-surface2/50 rounded-lg">
                    <div className="flex items-center gap-3">
                      {getCallIcon(call.callType)}
                      <div>
                        <p className="text-text font-medium">{call.phoneNumber}</p>
                        <p className="text-xs text-textMuted">
                          {new Date(call.timestamp).toLocaleString()} • {call.duration > 0 ? `${call.duration}s` : '-'}
                        </p>
                      </div>
                    </div>
                    <button className="text-textMuted hover:text-error">
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                ))
              )}
            </div>
          </div>
        </>
      )}
    </div>
  );
}