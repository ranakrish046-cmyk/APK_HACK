import React from 'react';
import { useDeviceStore } from '../../store/deviceStore';
import { Globe, Key, Bookmark, History, Download } from 'lucide-react';

export default function Browser() {
  const { selectedDevice, sendCommand } = useDeviceStore();

  if (!selectedDevice) {
    return (
      <div className="p-6">
        <h1 className="text-2xl font-bold text-text mb-1">🌐 Browser Data</h1>
        <div className="card text-center py-12">
          <Globe className="w-16 h-16 text-textMuted mx-auto mb-4" />
          <p className="text-textMuted">Select a device to view browser data</p>
        </div>
      </div>
    );
  }

  const savedPasswords = [
    { site: 'google.com', username: 'user@gmail.com', password: 'password123' },
    { site: 'facebook.com', username: 'user.fb', password: 'fbpass456' },
  ];

  const history = [
    { url: 'https://google.com', title: 'Google', time: '2026-09-17 14:30' },
    { url: 'https://youtube.com', title: 'YouTube', time: '2026-09-17 14:25' },
  ];

  return (
    <div className="p-6 space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-text mb-1">🌐 Browser Data</h1>
        <p className="text-textMuted">View history, passwords, and bookmarks</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="card">
          <h3 className="text-lg font-semibold text-text mb-4 flex items-center gap-2">
            <Key className="w-5 h-5 text-primary" /> Saved Passwords
          </h3>
          <div className="space-y-3">
            {savedPasswords.map((pwd, i) => (
              <div key={i} className="p-3 bg-surface2/50 rounded-lg">
                <p className="text-text font-semibold mb-1">{pwd.site}</p>
                <p className="text-sm text-textMuted mb-1">{pwd.username}</p>
                <p className="text-sm font-mono text-primary">{pwd.password}</p>
              </div>
            ))}
          </div>
        </div>

        <div className="card">
          <h3 className="text-lg font-semibold text-text mb-4 flex items-center gap-2">
            <History className="w-5 h-5 text-secondary" /> History
          </h3>
          <div className="space-y-2">
            {history.map((item, i) => (
              <div key={i} className="p-3 bg-surface2/50 rounded-lg">
                <p className="text-text font-medium mb-1">{item.title}</p>
                <p className="text-xs text-textMuted font-mono mb-1">{item.url}</p>
                <p className="text-xs text-textMuted">{item.time}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}