import React from 'react';
import { useDeviceStore } from '../../store/deviceStore';
import { MapPin, Navigation, GPS, AlertCircle } from 'lucide-react';
import { MapContainer, TileLayer, Marker, Popup } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';

export default function Location() {
  const { selectedDevice } = useDeviceStore();

  if (!selectedDevice) {
    return (
      <div className="p-6">
        <h1 className="text-2xl font-bold text-text mb-1">📍 Location</h1>
        <div className="card text-center py-12">
          <MapPin className="w-16 h-16 text-textMuted mx-auto mb-4" />
          <p className="text-textMuted">Select a device to view location</p>
        </div>
      </div>
    );
  }

  const position = [selectedDevice.latitude || 20, selectedDevice.longitude || 0];

  return (
    <div className="p-6 space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-text mb-1">📍 GPS Location</h1>
        <p className="text-textMuted">Real-time location tracking and history</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 card">
          <h3 className="text-lg font-semibold text-text mb-4">Live Map</h3>
          <div className="aspect-video rounded-lg overflow-hidden">
            {selectedDevice.latitude && selectedDevice.longitude ? (
              <MapContainer center={position} zoom={13} style={{ height: '100%', width: '100%' }}>
                <TileLayer url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" />
                <Marker position={position}>
                  <Popup>{selectedDevice.deviceName}</Popup>
                </Marker>
              </MapContainer>
            ) : (
              <div className="h-full flex items-center justify-center text-textMuted">
                <GPS className="w-8 h-8 animate-pulse" /> Getting GPS signal...
              </div>
            )}
          </div>
        </div>

        <div className="space-y-4">
          <div className="card">
            <h3 className="text-lg font-semibold text-text mb-4">Location Details</h3>
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-textMuted">Latitude</span>
                <span className="font-mono text-text">{selectedDevice.latitude?.toFixed(6) || 'N/A'}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-textMuted">Longitude</span>
                <span className="font-mono text-text">{selectedDevice.longitude?.toFixed(6) || 'N/A'}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-textMuted">Accuracy</span>
                <span className="text-text">±10m</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-textMuted">Speed</span>
                <span className="text-text">0 km/h</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-textMuted">Altitude</span>
                <span className="text-text">150m</span>
              </div>
            </div>
          </div>

          <div className="card">
            <h3 className="text-lg font-semibold text-text mb-4">Geofencing</h3>
            <button className="w-full btn-primary">Add Geofence Alert</button>
          </div>
        </div>
      </div>
    </div>
  );
}