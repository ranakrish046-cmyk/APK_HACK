import React from 'react';
import { useDeviceStore } from '../../store/deviceStore';
import { 
  Activity, Users, Smartphone, Laptop, TrendingUp, 
  Map, Clock, Database, Server
} from 'lucide-react';
import { PieChart, Pie, Cell, Tooltip, ResponsiveContainer } from 'recharts';

const COLORS = ['#00ff88', '#00d4ff'];

const StatCard = ({ icon: Icon, label, value, color, trend }) => (
  <div className="glass-panel p-6">
    <div className="flex items-center justify-between mb-4">
      <div className={`p-3 rounded-lg ${color.replace('text-', 'bg-')}/10`}>
        <Icon className={`w-6 h-6 ${color}`} />
      </div>
      {trend && (
        <span className="text-xs text-success bg-success/10 px-2 py-1 rounded-full">
          {trend}
        </span>
      )}
    </div>
    <p className="text-3xl font-bold text-text mb-1">{value}</p>
    <p className="text-sm text-textMuted">{label}</p>
  </div>
);

const StatRow = ({ label, value, icon: Icon }) => (
  <div className="flex items-center justify-between p-3 bg-surface2/50 rounded-lg">
    <div className="flex items-center gap-3">
      <Icon className="w-4 h-4 text-textMuted" />
      <span className="text-sm text-textMuted">{label}</span>
    </div>
    <span className="text-sm font-semibold text-text">{value}</span>
  </div>
);

export default function Dashboard() {
  const { devices, stats } = useDeviceStore();

  const androidCount = devices.filter(d => d.platform === 'android').length;
  const windowsCount = devices.filter(d => d.platform === 'windows').length;
  const onlineCount = devices.filter(d => d.isOnline).length;

  const platformData = [
    { name: 'Android', value: androidCount },
    { name: 'Windows', value: windowsCount },
  ];

  return (
    <div className="p-6 space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-text mb-2">Dashboard</h1>
        <p className="text-textMuted">Overview of all connected devices</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard icon={Activity} label="Total Devices" value={stats?.totalDevices || 0} color="text-primary" trend="+12%" />
        <StatCard icon={Users} label="Online Now" value={stats?.onlineDevices || 0} color="text-success" />
        <StatCard icon={Smartphone} label="Android" value={androidCount} color="text-secondary" />
        <StatCard icon={Laptop} label="Windows" value={windowsCount} color="text-accent" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="card">
          <h3 className="text-lg font-semibold text-text mb-4">Platform Distribution</h3>
          <ResponsiveContainer width="100%" height={250}>
            <PieChart>
              <Pie data={platformData} cx="50%" cy="50%" innerRadius={60} outerRadius={80} dataKey="value">
                {platformData.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
              </Pie>
              <Tooltip contentStyle={{ backgroundColor: '#1a1a1a', border: '1px solid #333' }} />
            </PieChart>
          </ResponsiveContainer>
        </div>

        <div className="card">
          <h3 className="text-lg font-semibold text-text mb-4">Quick Stats</h3>
          <div className="space-y-3">
            <StatRow label="Today's New Devices" value={stats?.todayDevices || 0} icon={TrendingUp} />
            <StatRow label="Total Data Collected" value="2.4 GB" icon={Database} />
            <StatRow label="Average Uptime" value="18h 32m" icon={Clock} />
            <StatRow label="Active Sessions" value={onlineCount} icon={Server} />
          </div>
        </div>
      </div>

      {/* Recent Devices */}
      <div className="card">
        <h3 className="text-lg font-semibold text-text mb-4">Recent Devices</h3>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="border-b border-border">
              <tr className="text-textMuted">
                <th className="text-left p-3">Device</th>
                <th className="text-left p-3">Platform</th>
                <th className="text-left p-3">IP Address</th>
                <th className="text-left p-3">Battery</th>
                <th className="text-left p-3">Status</th>
              </tr>
            </thead>
            <tbody>
              {devices.slice(0, 5).map((device) => (
                <tr key={device.sessionId} className="border-b border-border/50 hover:bg-surface2/50">
                  <td className="p-3 text-text">{device.deviceName}</td>
                  <td className="p-3 text-textMuted">{device.platform}</td>
                  <td className="p-3 font-mono text-textMuted">{device.ipAddress}</td>
                  <td className="p-3 text-textMuted">{device.batteryLevel}%</td>
                  <td className="p-3">
                    <span className={`px-2 py-1 rounded-full text-xs ${device.isOnline ? 'bg-success/10 text-success' : 'bg-textMuted/10 text-textMuted'}`}>
                      {device.isOnline ? 'Online' : 'Offline'}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}