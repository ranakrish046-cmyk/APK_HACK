import React from 'react';
import { useDeviceStore } from '../../store/deviceStore';
import { Smartphone, Trash2, Play, Download, Shield } from 'lucide-react';

export default function Apps() {
  const { selectedDevice, sendCommand } = useDeviceStore();
  const [apps, setApps] = useState([
    { name: 'WhatsApp', package: 'com.whatsapp', system: false, icon: '💬' },
    { name: 'Chrome', package: 'com.android.chrome', system: false, icon: '🌐' },
    { name: 'Instagram', package: 'com.instagram.android', system: false, icon: '📸' },
    { name: 'Settings', package: 'com.android.settings', system: true, icon: '⚙️' },
  ]);

  if (!selectedDevice) {
    return (
      <div className="p-6">
        <h1 className="text-2xl font-bold text-text mb-1">📱 Apps</h1>
        <div className="card text-center py-12">
          <Smartphone className="w-16 h-16 text-textMuted mx-auto mb-4" />
          <p className="text-textMuted">Select a device to view apps</p>
        </div>
      </div>
    );
  }

  const handleUninstall = (pkg) => {
    sendCommand(selectedDevice.sessionId, 'app:uninstall', { package: pkg });
  };

  const handleLaunch = (pkg) => {
    sendCommand(selectedDevice.sessionId, 'app:launch', { package: pkg });
  };

  return (
    <div className="p-6 space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-text mb-1">📱 Installed Apps</h1>
        <p className="text-textMuted">Manage installed applications ({apps.length} apps)</p>
      </div>

      <div className="card">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {apps.map((app, i) => (
            <div key={i} className="p-4 bg-surface2/50 rounded-lg border border-border">
              <div className="flex items-start justify-between mb-3">
                <div className="text-3xl">{app.icon}</div>
                <div className="flex gap-1">
                  <button onClick={() => handleLaunch(app.package)} className="p-1 hover:bg-primary/20 rounded">
                    <Play className="w-4 h-4" />
                  </button>
                  {!app.system && (
                    <button onClick={() => handleUninstall(app.package)} className="p-1 hover:bg-error/20 rounded">
                      <Trash2 className="w-4 h-4" />
                    </button>
                  )}
                </div>
              </div>
              <h4 className="text-text font-semibold mb-1">{app.name}</h4>
              <p className="text-xs text-textMuted font-mono mb-2">{app.package}</p>
              {app.system && <span className="px-2 py-0.5 bg-textMuted/20 text-textMuted text-xs rounded">System</span>}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}