import React, { useState } from 'react';
import { useDeviceStore } from '../../store/deviceStore';
import { Mic, Square, Play, Download, Volume2 } from 'lucide-react';

export default function Microphone() {
  const { selectedDevice, sendCommand } = useDeviceStore();
  const [recording, setRecording] = useState(false);
  const [duration, setDuration] = useState(60);
  const [recordings, setRecordings] = useState([]);

  const handleRecord = () => {
    if (!selectedDevice) return;
    setRecording(true);
    sendCommand(selectedDevice.sessionId, 'mic:record', { duration });
    setTimeout(() => setRecording(false), duration * 1000);
  };

  const handleLiveListen = () => {
    if (!selectedDevice) return;
    sendCommand(selectedDevice.sessionId, 'mic:livelisten', {});
  };

  return (
    <div className="p-6 space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-text mb-1">🎤 Microphone</h1>
        <p className="text-textMuted">Record audio and listen live from device</p>
      </div>

      {!selectedDevice ? (
        <div className="card text-center py-12">
          <Mic className="w-16 h-16 text-textMuted mx-auto mb-4" />
          <p className="text-textMuted">Select a device to access microphone</p>
        </div>
      ) : (
        <>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="card">
              <h3 className="text-lg font-semibold text-text mb-4">Record Audio</h3>
              <div className="flex gap-2 mb-4">
                {[10, 30, 60, 300].map((d) => (
                  <button
                    key={d}
                    onClick={() => setDuration(d)}
                    className={`flex-1 py-2 rounded-lg transition-all ${
                      duration === d ? 'bg-primary/20 text-primary border border-primary/50' : 'bg-surface2 text-textMuted'
                    }`}
                  >
                    {d >= 60 ? `${d / 60}m` : `${d}s`}
                  </button>
                ))}
              </div>
              <button
                onClick={handleRecord}
                disabled={recording}
                className={`w-full py-3 rounded-lg flex items-center justify-center gap-2 transition-all ${
                  recording ? 'bg-error/20 text-error' : 'btn-primary'
                }`}
              >
                {recording ? (
                  <>
                    <Square className="w-5 h-5 fill-current" />
                    <span>Recording... ({duration}s)</span>
                  </>
                ) : (
                  <>
                    <Mic className="w-5 h-5" />
                    <span>Start Recording</span>
                  </>
                )}
              </button>
            </div>

            <div className="card">
              <h3 className="text-lg font-semibold text-text mb-4">Live Audio</h3>
              <button
                onClick={handleLiveListen}
                className="w-full btn-primary py-3 flex items-center justify-center gap-2"
              >
                <Volume2 className="w-5 h-5" />
                <span>Start Live Listening</span>
              </button>
              <p className="text-xs text-textMuted mt-3 text-center">
                Audio streams in real-time with low latency
              </p>
            </div>
          </div>

          <div className="card">
            <h3 className="text-lg font-semibold text-text mb-4">Recordings</h3>
            <div className="space-y-2">
              {[1, 2, 3].map((i) => (
                <div key={i} className="flex items-center justify-between p-3 bg-surface2/50 rounded-lg">
                  <div className="flex items-center gap-3">
                    <Play className="w-4 h-4 text-primary" />
                    <span className="text-sm text-text">recording_{i}.mp3</span>
                    <span className="text-xs text-textMuted">2.4 MB • 2026-09-17 14:30</span>
                  </div>
                  <button className="btn-secondary flex items-center gap-2">
                    <Download className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>
          </div>
        </>
      )}
    </div>
  );
}