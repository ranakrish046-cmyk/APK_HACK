import React, { useState } from 'react';
import { useDeviceStore } from '../../store/deviceStore';
import { Monitor, Screenshot, Video, MouseClick, Type, PowerOff, Eye } from 'lucide-react';

export default function Screen() {
  const { selectedDevice, sendCommand } = useDeviceStore();
  const [capturing, setCapturing] = useState(false);

  const handleScreenshot = () => {
    if (!selectedDevice) return;
    setCapturing(true);
    sendCommand(selectedDevice.sessionId, 'screen:screenshot', {});
    setTimeout(() => setCapturing(false), 1500);
  };

  const handleScreenRecord = () => {
    if (!selectedDevice) return;
    sendCommand(selectedDevice.sessionId, 'screen:record', { duration: 60 });
  };

  const handleRemoteControl = (action, payload) => {
    if (!selectedDevice) return;
    sendCommand(selectedDevice.sessionId, 'screen:control', { action, ...payload });
  };

  return (
    <div className="p-6 space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-text mb-1">🖥️ Screen</h1>
        <p className="text-textMuted">Capture screenshots, record screen, and remote control</p>
      </div>

      {!selectedDevice ? (
        <div className="card text-center py-12">
          <Monitor className="w-16 h-16 text-textMuted mx-auto mb-4" />
          <p className="text-textMuted">Select a device to access screen</p>
        </div>
      ) : (
        <>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <button onClick={handleScreenshot} className="card btn-primary flex flex-col items-center gap-2">
              <Screenshot className="w-6 h-6" />
              <span>Screenshot</span>
            </button>
            <button onClick={handleScreenRecord} className="card btn-secondary flex flex-col items-center gap-2">
              <Video className="w-6 h-6" />
              <span>Record Screen</span>
            </button>
            <button onClick={() => handleRemoteControl('black_screen')} className="card btn-secondary flex flex-col items-center gap-2">
              <PowerOff className="w-6 h-6" />
              <span>Black Screen</span>
            </button>
            <button onClick={() => handleRemoteControl('overlay')} className="card btn-secondary flex flex-col items-center gap-2">
              <Eye className="w-6 h-6" />
              <span>Overlay</span>
            </button>
          </div>

          <div className="card">
            <h3 className="text-lg font-semibold text-text mb-4">Remote Control</h3>
            <div className="grid grid-cols-3 gap-3 mb-4">
              <button onClick={() => handleRemoteControl('tap', { x: 100, y: 100 })} className="btn-secondary">
                <MouseClick className="w-4 h-4" /> Tap
              </button>
              <button onClick={() => handleRemoteControl('swipe', { from: 'top', to: 'bottom' })} className="btn-secondary">
                Swipe Down
              </button>
              <button onClick={() => handleRemoteControl('type', { text: 'Hello' })} className="btn-secondary">
                <Type className="w-4 h-4" /> Type
              </button>
            </div>
            <div className="aspect-video bg-surface2 rounded-lg flex items-center justify-center border border-border">
              <p className="text-textMuted">Live screen preview will appear here</p>
            </div>
          </div>
        </>
      )}
    </div>
  );
}