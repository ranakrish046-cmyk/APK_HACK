import React, { useState } from 'react';
import { useDeviceStore } from '../../store/deviceStore';
import { Folder, File, Download, Upload, Trash2, Plus, Search, ArrowLeft } from 'lucide-react';

export default function Files() {
  const { selectedDevice, sendCommand } = useDeviceStore();
  const [currentPath, setCurrentPath] = useState('/');
  const [files, setFiles] = useState([]);
  const [search, setSearch] = useState('');

  const loadFiles = (path) => {
    if (!selectedDevice) return;
    sendCommand(selectedDevice.sessionId, 'file:list', { path });
  };

  const handleDownload = (file) => {
    sendCommand(selectedDevice.sessionId, 'file:download', { path: `${currentPath}/${file.name}` });
  };

  const handleUpload = () => {
    const input = document.createElement('input');
    input.type = 'file';
    input.onchange = (e) => {
      const file = e.target.files[0];
      sendCommand(selectedDevice.sessionId, 'file:upload', { path: currentPath, file });
    };
    input.click();
  };

  return (
    <div className="p-6 space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-text mb-1">📁 File Manager</h1>
        <p className="text-textMuted">Browse, upload, download, and manage files</p>
      </div>

      {!selectedDevice ? (
        <div className="card text-center py-12">
          <Folder className="w-16 h-16 text-textMuted mx-auto mb-4" />
          <p className="text-textMuted">Select a device to access files</p>
        </div>
      ) : (
        <>
          <div className="card">
            <div className="flex items-center gap-3 mb-4">
              <input
                type="text"
                value={currentPath}
                onChange={(e) => setCurrentPath(e.target.value)}
                className="input-field flex-1 font-mono"
              />
              <button onClick={() => loadFiles(currentPath)} className="btn-primary">Go</button>
              <button onClick={handleUpload} className="btn-secondary flex items-center gap-2">
                <Upload className="w-4 h-4" /> Upload
              </button>
            </div>
            <div className="flex items-center gap-3">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-textMuted" />
                <input
                  type="text"
                  placeholder="Search files..."
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  className="input-field pl-9"
                />
              </div>
            </div>
          </div>

          <div className="card">
            <div className="grid grid-cols-4 md:grid-cols-6 lg:grid-cols-8 gap-4">
              {files.length === 0 && (
                <p className="text-textMuted text-center col-span-full py-8">No files in this directory</p>
              )}
              {[
                { name: 'Downloads', type: 'folder' },
                { name: 'Pictures', type: 'folder' },
                { name: 'Documents', type: 'folder' },
                { name: 'photos.zip', type: 'file', size: '24.5 MB' },
                { name: 'notes.txt', type: 'file', size: '1.2 KB' },
              ].map((file, i) => (
                <div key={i} className="flex flex-col items-center p-4 bg-surface2/50 rounded-lg hover:bg-surface2 transition-all">
                  {file.type === 'folder' ? (
                    <Folder className="w-12 h-12 text-primary mb-2" />
                  ) : (
                    <File className="w-12 h-12 text-secondary mb-2" />
                  )}
                  <span className="text-xs text-text text-center mb-2">{file.name}</span>
                  {file.size && <span className="text-xs text-textMuted mb-2">{file.size}</span>}
                  <div className="flex gap-1">
                    <button onClick={() => handleDownload(file)} className="p-1 hover:bg-primary/20 rounded">
                      <Download className="w-3 h-3" />
                    </button>
                    <button className="p-1 hover:bg-error/20 rounded">
                      <Trash2 className="w-3 h-3" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </>
      )}
    </div>
  );
}