import React, { useState } from 'react';
import { NavLink } from 'react-router-dom';
import { useDeviceStore } from '../../store/deviceStore';
import { 
  LayoutDashboard, Camera, Mic, Monitor, Keyboard, 
  MessageSquare, Phone, Folder, MapPin, Users, 
  Smartphone, Globe, Settings, Battery, Wifi,
  Search, Filter, Power, Cpu
} from 'lucide-react';

const menuItems = [
  { icon: LayoutDashboard, label: 'Dashboard', path: '/' },
  { icon: Camera, label: 'Camera', path: '/camera' },
  { icon: Mic, label: 'Microphone', path: '/microphone' },
  { icon: Monitor, label: 'Screen', path: '/screen' },
  { icon: Keyboard, label: 'Keylogger', path: '/keylogger' },
  { icon: MessageSquare, label: 'SMS', path: '/sms' },
  { icon: Phone, label: 'Calls', path: '/calls' },
  { icon: Folder, label: 'Files', path: '/files' },
  { icon: MapPin, label: 'Location', path: '/location' },
  { icon: Users, label: 'Contacts', path: '/contacts' },
  { icon: Smartphone, label: 'Apps', path: '/apps' },
  { icon: Globe, label: 'Browser', path: '/browser' },
];

export default function Sidebar() {
  const { devices, selectedDevice, selectDevice, logout } = useDeviceStore();
  const [filter, setFilter] = useState('all');
  const [search, setSearch] = useState('');

  const filteredDevices = devices.filter(device => {
    const matchesFilter = 
      filter === 'all' || 
      (filter === 'online' && device.isOnline) || 
      (filter === 'offline' && !device.isOnline);
    
    const matchesSearch = 
      device.deviceName.toLowerCase().includes(search.toLowerCase()) ||
      device.model.toLowerCase().includes(search.toLowerCase()) ||
      device.sessionId.toLowerCase().includes(search.toLowerCase());
    
    return matchesFilter && matchesSearch;
  });

  const getPlatformIcon = (platform) => {
    return platform === 'android' ? '🤖' : '💻';
  };

  return (
    <aside className="w-80 bg-surface border-r border-border flex flex-col">
      {/* Logo */}
      <div className="p-4 border-b border-border">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
            <Cpu className="w-6 h-6 text-primary" />
          </div>
          <div>
            <h1 className="text-lg font-bold neon-text">Ultimate RAT</h1>
            <p className="text-xs text-textMuted">v2026.1.0</p>
          </div>
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 overflow-y-auto p-2">
        <div className="space-y-1">
          {menuItems.map((item) => (
            <NavLink
              key={item.path}
              to={item.path}
              className={({ isActive }) =>
                `flex items-center gap-3 px-3 py-2.5 rounded-lg transition-all duration-200 ${
                  isActive
                    ? 'bg-primary/10 text-primary border border-primary/20'
                    : 'text-textMuted hover:bg-surface2 hover:text-text'
                }`
              }
            >
              <item.icon className="w-5 h-5" />
              <span className="text-sm font-medium">{item.label}</span>
            </NavLink>
          ))}
        </div>

        <div className="mt-6 pt-6 border-t border-border">
          <h3 className="px-3 text-xs font-semibold text-textMuted uppercase tracking-wider mb-2">
            Connected Devices ({devices.length})
          </h3>

          {/* Search & Filter */}
          <div className="px-2 mb-3 space-y-2">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-textMuted" />
              <input
                type="text"
                placeholder="Search devices..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="input-field pl-9 text-sm w-full"
              />
            </div>
            <div className="flex gap-1">
              {['all', 'online', 'offline'].map((f) => (
                <button
                  key={f}
                  onClick={() => setFilter(f)}
                  className={`flex-1 px-2 py-1 text-xs rounded-md transition-all ${
                    filter === f
                      ? 'bg-primary/10 text-primary border border-primary/20'
                      : 'bg-surface2 text-textMuted border border-transparent'
                  }`}
                >
                  {f.charAt(0).toUpperCase() + f.slice(1)}
                </button>
              ))}
            </div>
          </div>

          {/* Device List */}
          <div className="space-y-1">
            {filteredDevices.map((device) => (
              <button
                key={device.sessionId}
                onClick={() => selectDevice(device)}
                className={`w-full p-3 rounded-lg transition-all duration-200 text-left ${
                  selectedDevice?.sessionId === device.sessionId
                    ? 'bg-primary/10 border border-primary/20'
                    : 'bg-surface2/50 border border-transparent hover:bg-surface2'
                }`}
              >
                <div className="flex items-start gap-3">
                  <div className="text-2xl">{getPlatformIcon(device.platform)}</div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <p className="text-sm font-medium text-text truncate">
                        {device.deviceName}
                      </p>
                      <div className={`status-dot ${device.isOnline ? 'online' : 'offline'}`}></div>
                    </div>
                    <p className="text-xs text-textMuted truncate">{device.model}</p>
                    <div className="flex items-center gap-2 mt-1">
                      <div className="flex items-center gap-1">
                        <Battery className="w-3 h-3 text-textMuted" />
                        <span className="text-xs text-textMuted">{device.batteryLevel}%</span>
                      </div>
                      {device.isCharging && (
                        <span className="text-xs text-success">⚡</span>
                      )}
                    </div>
                  </div>
                </div>
              </button>
            ))}
          </div>
        </div>
      </nav>

      {/* Footer */}
      <div className="p-4 border-t border-border">
        <button
          onClick={logout}
          className="w-full flex items-center justify-center gap-2 px-4 py-2 bg-error/10 hover:bg-error/20 text-error border border-error/20 rounded-lg transition-all duration-200"
        >
          <Power className="w-4 h-4" />
          <span className="text-sm font-medium">Logout</span>
        </button>
      </div>
    </aside>
  );
}