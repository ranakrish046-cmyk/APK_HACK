import React from 'react';
import { Outlet } from 'react-router-dom';

export default function MainPanel() {
  return (
    <main className="flex-1 overflow-y-auto bg-background">
      <Outlet />
    </main>
  );
}