import React from 'react';
import { useDeviceStore } from '../../store/deviceStore';
import { Bell, Wifi, WifiOff, User, Activity } from 'lucide-react';

export default function Topbar() {
  const { selectedDevice, stats, isConnected } = useDeviceStore();

  return (
    <header className="h-16 bg-surface/50 backdrop-blur-xl border-b border-border flex items-center justify-between px-6">
      <div className="flex items-center gap-4">
        {selectedDevice ? (
          <div>
            <h2 className="text-lg font-semibold text-text">
              {selectedDevice.deviceName}
            </h2>
            <div className="flex items-center gap-3 text-xs text-textMuted">
              <span>{selectedDevice.model}</span>
              <span>•</span>
              <span>{selectedDevice.ipAddress}</span>
              <span>•</span>
              <span className={`font-mono ${selectedDevice.isOnline ? 'text-success' : 'text-textMuted'}`}>
                {selectedDevice.sessionId.slice(0, 8)}...
              </span>
            </div>
          </div>
        ) : (
          <h2 className="text-lg font-semibold text-text">Select a device</h2>
        )}
      </div>

      <div className="flex items-center gap-6">
        {/* Quick Stats */}
        {stats && (
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2">
              <Activity className="w-4 h-4 text-primary" />
              <div className="text-right">
                <p className="text-xs text-textMuted">Online</p>
                <p className="text-sm font-semibold text-text">{stats.onlineDevices}</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <User className="w-4 h-4 text-secondary" />
              <div className="text-right">
                <p className="text-xs text-textMuted">Total</p>
                <p className="text-sm font-semibold text-text">{stats.totalDevices}</p>
              </div>
            </div>
          </div>
        )}

        {/* Connection Status */}
        <div className="flex items-center gap-2">
          {isConnected ? (
            <Wifi className="w-4 h-4 text-success" />
          ) : (
            <WifiOff className="w-4 h-4 text-error" />
          )}
          <span className="text-xs text-textMuted">
            {isConnected ? 'Connected' : 'Disconnected'}
          </span>
        </div>

        {/* Notifications */}
        <button className="relative p-2 hover:bg-surface2 rounded-lg transition-all">
          <Bell className="w-5 h-5 text-textMuted" />
          <span className="absolute top-1 right-1 w-2 h-2 bg-error rounded-full"></span>
        </button>
      </div>
    </header>
  );
}