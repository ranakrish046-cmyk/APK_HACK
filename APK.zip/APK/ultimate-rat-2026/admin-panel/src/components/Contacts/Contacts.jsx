import React from 'react';
import { useDeviceStore } from '../../store/deviceStore';
import { Users, Download, Plus, Trash2, Phone, Mail } from 'lucide-react';

export default function Contacts() {
  const { selectedDevice, sendCommand } = useDeviceStore();
  const [contacts, setContacts] = useState([
    { name: 'John Doe', phone: '+1234567890', email: 'john@example.com' },
    { name: 'Jane Smith', phone: '+0987654321', email: 'jane@example.com' },
    { name: 'Bob Wilson', phone: '+1122334455', email: 'bob@example.com' },
  ]);

  if (!selectedDevice) {
    return (
      <div className="p-6">
        <h1 className="text-2xl font-bold text-text mb-1">👥 Contacts</h1>
        <div className="card text-center py-12">
          <Users className="w-16 h-16 text-textMuted mx-auto mb-4" />
          <p className="text-textMuted">Select a device to view contacts</p>
        </div>
      </div>
    );
  }

  const exportContacts = () => {
    const vcard = contacts.map(c => `BEGIN:VCARD\nVERSION:3.0\nFN:${c.name}\nTEL:${c.phone}\nEMAIL:${c.email}\nEND:VCARD`).join('\n');
    const blob = new Blob([vcard], { type: 'text/vcard' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'contacts.vcf';
    a.click();
  };

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-text mb-1">👥 Contacts</h1>
          <p className="text-textMuted">View and manage device contacts</p>
        </div>
        <button onClick={exportContacts} className="btn-secondary flex items-center gap-2">
          <Download className="w-4 h-4" /> Export vCard
        </button>
      </div>

      <div className="card">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {contacts.map((contact, i) => (
            <div key={i} className="p-4 bg-surface2/50 rounded-lg border border-border">
              <div className="flex items-start justify-between mb-3">
                <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center">
                  <span className="text-primary font-bold text-lg">{contact.name.charAt(0)}</span>
                </div>
                <button className="text-textMuted hover:text-error">
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
              <h4 className="text-text font-semibold mb-2">{contact.name}</h4>
              <div className="space-y-1 text-sm text-textMuted">
                <div className="flex items-center gap-2">
                  <Phone className="w-4 h-4" /> {contact.phone}
                </div>
                <div className="flex items-center gap-2">
                  <Mail className="w-4 h-4" /> {contact.email}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}