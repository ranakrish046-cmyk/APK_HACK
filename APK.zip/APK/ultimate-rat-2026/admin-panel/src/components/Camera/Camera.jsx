import React, { useState } from 'react';
import { useDeviceStore } from '../../store/deviceStore';
import { Camera, Video, Download, RefreshCw, Settings, Image as ImageIcon } from 'lucide-react';

export default function Camera() {
  const { selectedDevice, sendCommand } = useDeviceStore();
  const [capturing, setCapturing] = useState(false);
  const [quality, setQuality] = useState('high');
  const [screenshots, setScreenshots] = useState([]);

  const handleCapture = (camera) => {
    if (!selectedDevice) return;
    setCapturing(true);
    sendCommand(selectedDevice.sessionId, 'camera:capture', { camera, quality });
    setTimeout(() => setCapturing(false), 2000);
  };

  const handleLiveStream = () => {
    if (!selectedDevice) return;
    sendCommand(selectedDevice.sessionId, 'camera:livestream', { fps: 5, quality });
  };

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-text mb-1">📷 Camera</h1>
          <p className="text-textMuted">Capture photos and stream video from device cameras</p>
        </div>
        {selectedDevice && (
          <select 
            value={quality} 
            onChange={(e) => setQuality(e.target.value)}
            className="input-field"
          >
            <option value="low">Low Quality</option>
            <option value="medium">Medium Quality</option>
            <option value="high">High Quality</option>
          </select>
        )}
      </div>

      {!selectedDevice ? (
        <div className="card text-center py-12">
          <Camera className="w-16 h-16 text-textMuted mx-auto mb-4" />
          <p className="text-textMuted">Select a device to access camera</p>
        </div>
      ) : (
        <>
          {/* Camera Controls */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <button
              onClick={() => handleCapture('front')}
              disabled={capturing}
              className="card btn-primary flex flex-col items-center gap-3 hover:scale-105 transition-transform"
            >
              <Camera className="w-8 h-8" />
              <span>Front Camera</span>
            </button>
            <button
              onClick={() => handleCapture('back')}
              disabled={capturing}
              className="card btn-primary flex flex-col items-center gap-3 hover:scale-105 transition-transform"
            >
              <Camera className="w-8 h-8" />
              <span>Back Camera</span>
            </button>
            <button
              onClick={handleLiveStream}
              disabled={capturing}
              className="card btn-secondary flex flex-col items-center gap-3 hover:scale-105 transition-transform"
            >
              <Video className="w-8 h-8" />
              <span>Live Stream (5 FPS)</span>
            </button>
          </div>

          {/* Screenshots Gallery */}
          <div className="card">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-text">Captured Images</h3>
              <button className="btn-secondary flex items-center gap-2">
                <Download className="w-4 h-4" />
                <span>Download All</span>
              </button>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {[1, 2, 3, 4].map((i) => (
                <div key={i} className="aspect-square bg-surface2 rounded-lg flex items-center justify-center border border-border">
                  <ImageIcon className="w-8 h-8 text-textMuted" />
                </div>
              ))}
            </div>
          </div>
        </>
      )}
    </div>
  );
}