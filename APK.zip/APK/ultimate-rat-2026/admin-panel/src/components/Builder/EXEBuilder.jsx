import React, { useState } from 'react';
import { Save, Upload, Settings, Monitor, Download, Shield } from 'lucide-react';

export default function EXEBuilder() {
  const [config, setConfig] = useState({
    exeName: 'rat_client',
    c2Server: 'http://your-server-ip:3000',
    icon: null,
    hideConsole: true,
    runAsAdmin: true,
    persistence: true,
    obfuscation: true
  });

  const handleBuild = () => {
    console.log('Building EXE with config:', config);
  };

  return (
    <div className="p-6 space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-text mb-1">💻 EXE Builder</h1>
        <p className="text-textMuted">Configure and build Windows payloads</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="card">
          <h3 className="text-lg font-semibold text-text mb-4">Basic Settings</h3>
          <div className="space-y-4">
            <div>
              <label className="block text-sm text-textMuted mb-2">EXE Name</label>
              <input
                type="text"
                value={config.exeName}
                onChange={(e) => setConfig({ ...config, exeName: e.target.value })}
                className="input-field w-full"
              />
            </div>
            <div>
              <label className="block text-sm text-textMuted mb-2">C2 Server URL</label>
              <input
                type="text"
                value={config.c2Server}
                onChange={(e) => setConfig({ ...config, c2Server: e.target.value })}
                className="input-field w-full"
              />
            </div>
          </div>
        </div>

        <div className="card">
          <h3 className="text-lg font-semibold text-text mb-4">Options</h3>
          <div className="space-y-3">
            <label className="flex items-center gap-3 p-3 bg-surface2/50 rounded-lg cursor-pointer">
              <input
                type="checkbox"
                checked={config.hideConsole}
                onChange={(e) => setConfig({ ...config, hideConsole: e.target.checked })}
                className="w-5 h-5"
              />
              <span className="text-text">Hide Console Window</span>
            </label>
            <label className="flex items-center gap-3 p-3 bg-surface2/50 rounded-lg cursor-pointer">
              <input
                type="checkbox"
                checked={config.runAsAdmin}
                onChange={(e) => setConfig({ ...config, runAsAdmin: e.target.checked })}
                className="w-5 h-5"
              />
              <span className="text-text">Run as Administrator</span>
            </label>
            <label className="flex items-center gap-3 p-3 bg-surface2/50 rounded-lg cursor-pointer">
              <input
                type="checkbox"
                checked={config.persistence}
                onChange={(e) => setConfig({ ...config, persistence: e.target.checked })}
                className="w-5 h-5"
              />
              <span className="text-text">Registry Persistence</span>
            </label>
            <label className="flex items-center gap-3 p-3 bg-surface2/50 rounded-lg cursor-pointer">
              <input
                type="checkbox"
                checked={config.obfuscation}
                onChange={(e) => setConfig({ ...config, obfuscation: e.target.checked })}
                className="w-5 h-5"
              />
              <span className="text-text">Code Obfuscation</span>
            </label>
          </div>
        </div>

        <div className="card">
          <h3 className="text-lg font-semibold text-text mb-4">Icon</h3>
          <div className="border-2 border-dashed border-border rounded-lg p-8 text-center">
            <Upload className="w-12 h-12 text-textMuted mx-auto mb-4" />
            <p className="text-textMuted mb-4">Upload .ico file</p>
            <button className="btn-primary">Choose Icon</button>
          </div>
        </div>

        <div className="card">
          <h3 className="text-lg font-semibold text-text mb-4">Build</h3>
          <button className="w-full btn-primary py-4 flex items-center justify-center gap-2" onClick={handleBuild}>
            <Save className="w-5 h-5" />
            <span>Build EXE</span>
          </button>
        </div>
      </div>
    </div>
  );
}