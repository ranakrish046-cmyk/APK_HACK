import React, { useState } from 'react';
import { Save, Upload, Settings, Smartphone, Download } from 'lucide-react';

export default function APKBuilder() {
  const [config, setConfig] = useState({
    appName: 'Ultimate RAT',
    packageName: 'com.ultimaterat.client',
    c2Server: 'http://your-server-ip:3000',
    icon: null,
    hideIcon: true,
    autoStart: true,
    stealthMode: true,
    batteryOptimization: true
  });

  const handleBuild = () => {
    // Send config to backend for APK building
    console.log('Building APK with config:', config);
    // Backend will use Gradle to build APK
  };

  return (
    <div className="p-6 space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-text mb-1">📱 APK Builder</h1>
        <p className="text-textMuted">Configure and build Android payloads</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="card">
          <h3 className="text-lg font-semibold text-text mb-4">Basic Settings</h3>
          <div className="space-y-4">
            <div>
              <label className="block text-sm text-textMuted mb-2">App Name</label>
              <input
                type="text"
                value={config.appName}
                onChange={(e) => setConfig({ ...config, appName: e.target.value })}
                className="input-field w-full"
              />
            </div>
            <div>
              <label className="block text-sm text-textMuted mb-2">Package Name</label>
              <input
                type="text"
                value={config.packageName}
                onChange={(e) => setConfig({ ...config, packageName: e.target.value })}
                className="input-field w-full"
              />
            </div>
            <div>
              <label className="block text-sm text-textMuted mb-2">C2 Server URL</label>
              <input
                type="text"
                value={config.c2Server}
                onChange={(e) => setConfig({ ...config, c2Server: e.target.value })}
                className="input-field w-full"
              />
            </div>
          </div>
        </div>

        <div className="card">
          <h3 className="text-lg font-semibold text-text mb-4">Stealth Options</h3>
          <div className="space-y-3">
            <label className="flex items-center gap-3 p-3 bg-surface2/50 rounded-lg cursor-pointer">
              <input
                type="checkbox"
                checked={config.hideIcon}
                onChange={(e) => setConfig({ ...config, hideIcon: e.target.checked })}
                className="w-5 h-5"
              />
              <span className="text-text">Hide App Icon</span>
            </label>
            <label className="flex items-center gap-3 p-3 bg-surface2/50 rounded-lg cursor-pointer">
              <input
                type="checkbox"
                checked={config.autoStart}
                onChange={(e) => setConfig({ ...config, autoStart: e.target.checked })}
                className="w-5 h-5"
              />
              <span className="text-text">Auto Start on Boot</span>
            </label>
            <label className="flex items-center gap-3 p-3 bg-surface2/50 rounded-lg cursor-pointer">
              <input
                type="checkbox"
                checked={config.stealthMode}
                onChange={(e) => setConfig({ ...config, stealthMode: e.target.checked })}
                className="w-5 h-5"
              />
              <span className="text-text">Stealth Mode (No Notification)</span>
            </label>
            <label className="flex items-center gap-3 p-3 bg-surface2/50 rounded-lg cursor-pointer">
              <input
                type="checkbox"
                checked={config.batteryOptimization}
                onChange={(e) => setConfig({ ...config, batteryOptimization: e.target.checked })}
                className="w-5 h-5"
              />
              <span className="text-text">Bypass Battery Optimization</span>
            </label>
          </div>
        </div>

        <div className="card">
          <h3 className="text-lg font-semibold text-text mb-4">App Icon</h3>
          <div className="border-2 border-dashed border-border rounded-lg p-8 text-center">
            <Upload className="w-12 h-12 text-textMuted mx-auto mb-4" />
            <p className="text-textMuted mb-4">Drag and drop icon here or click to browse</p>
            <button className="btn-primary">Choose File</button>
          </div>
        </div>

        <div className="card">
          <h3 className="text-lg font-semibold text-text mb-4">Build Options</h3>
          <div className="space-y-3">
            <button className="w-full btn-primary py-4 flex items-center justify-center gap-2" onClick={handleBuild}>
              <Save className="w-5 h-5" />
              <span>Build APK</span>
            </button>
            <button className="w-full btn-secondary py-3 flex items-center justify-center gap-2">
              <Download className="w-5 h-5" />
              <span>Download Template</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}