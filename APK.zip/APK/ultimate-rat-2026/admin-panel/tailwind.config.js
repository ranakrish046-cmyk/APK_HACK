/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        background: '#0a0a0a',
        surface: '#1a1a1a',
        surface2: '#252525',
        primary: '#00ff88',
        primaryDark: '#00cc6a',
        secondary: '#00d4ff',
        accent: '#ff006e',
        success: '#00ff88',
        warning: '#ffae00',
        error: '#ff006e',
        text: '#e0e0e0',
        textMuted: '#888888',
        border: '#333333',
      },
      fontFamily: {
        mono: ['Fira Code', 'monospace'],
      },
      animation: {
        'pulse-slow': 'pulse 3s cubic-bezier(0.4, 0, 0.6, 1) infinite',
        'bounce-slow': 'bounce 3s infinite',
      },
    },
  },
  plugins: [],
}