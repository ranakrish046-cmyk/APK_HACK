const CryptoJS = require('crypto-js');

const ENCRYPTION_KEY = process.env.ENCRYPTION_KEY || 'ultimate-rat-2026-secret-key-32chars';

const encrypt = (data) => {
  const jsonData = typeof data === 'object' ? JSON.stringify(data) : data;
  return CryptoJS.AES.encrypt(jsonData, ENCRYPTION_KEY).toString();
};

const decrypt = (encryptedData) => {
  const bytes = CryptoJS.AES.decrypt(encryptedData, ENCRYPTION_KEY);
  const decryptedData = bytes.toString(CryptoJS.enc.Utf8);
  try {
    return JSON.parse(decryptedData);
  } catch {
    return decryptedData;
  }
};

const generateSessionId = () => {
  return CryptoJS.lib.WordArray.random(16).toString(CryptoJS.enc.Hex);
};

module.exports = { encrypt, decrypt, generateSessionId };