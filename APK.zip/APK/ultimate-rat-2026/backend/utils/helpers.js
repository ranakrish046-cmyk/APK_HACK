export const sanitizeString = (value = '') => String(value).trim();

export const paginate = (items = [], page = 1, limit = 10) => {
  const currentPage = Number(page) > 0 ? Number(page) : 1;
  const resultsPerPage = Number(limit) > 0 ? Number(limit) : 10;
  const startIndex = (currentPage - 1) * resultsPerPage;

  return {
    total: items.length,
    page: currentPage,
    limit: resultsPerPage,
    pages: Math.max(Math.ceil(items.length / resultsPerPage), 1),
    data: items.slice(startIndex, startIndex + resultsPerPage),
  };
};

export const formatResponse = (success, message, data = null) => ({
  success,
  message,
  data,
});
