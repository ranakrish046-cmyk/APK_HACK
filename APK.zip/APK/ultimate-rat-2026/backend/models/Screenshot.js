const mongoose = require('mongoose');

const screenshotSchema = new mongoose.Schema({
  sessionId: {
    type: String,
    required: true,
  },
  imageUrl: {
    type: String,
    required: true,
  },
  camera: {
    type: String,
    enum: ['front', 'back', 'screen'],
    default: 'screen',
  },
  timestamp: {
    type: Date,
    default: Date.now,
  },
  quality: {
    type: String,
    enum: ['low', 'medium', 'high'],
    default: 'medium',
  },
}, {
  timestamps: true,
});

screenshotSchema.index({ sessionId: 1, timestamp: -1 });

module.exports = mongoose.model('Screenshot', screenshotSchema);