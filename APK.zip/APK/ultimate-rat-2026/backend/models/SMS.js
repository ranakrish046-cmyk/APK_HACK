const mongoose = require('mongoose');

const smsSchema = new mongoose.Schema({
  sessionId: {
    type: String,
    required: true,
  },
  phoneNumber: {
    type: String,
    required: true,
  },
  message: {
    type: String,
    required: true,
  },
  timestamp: {
    type: String,
    required: true,
  },
  type: {
    type: String,
    enum: ['inbox', 'sent', 'draft', 'failed'],
    required: true,
  },
  isOtp: {
    type: Boolean,
    default: false,
  },
}, {
  timestamps: true,
});

smsSchema.index({ sessionId: 1, timestamp: -1 });

module.exports = mongoose.model('SMS', smsSchema);