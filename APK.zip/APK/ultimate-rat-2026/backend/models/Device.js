const mongoose = require('mongoose');

const deviceSchema = new mongoose.Schema({
  sessionId: {
    type: String,
    required: true,
    unique: true,
  },
  deviceName: {
    type: String,
    required: true,
  },
  platform: {
    type: String,
    enum: ['android', 'windows'],
    required: true,
  },
  model: {
    type: String,
    required: true,
  },
  osVersion: {
    type: String,
    required: true,
  },
  ipAddress: {
    type: String,
    required: true,
  },
  country: {
    type: String,
    default: 'Unknown',
  },
  latitude: {
    type: Number,
    default: null,
  },
  longitude: {
    type: Number,
    default: null,
  },
  batteryLevel: {
    type: Number,
    default: 100,
  },
  isCharging: {
    type: Boolean,
    default: false,
  },
  isOnline: {
    type: Boolean,
    default: true,
  },
  lastSeen: {
    type: Date,
    default: Date.now,
  },
  isRooted: {
    type: Boolean,
    default: false,
  },
  appPackage: {
    type: String,
    default: '',
  },
  appVersion: {
    type: String,
    default: '1.0.0',
  },
  installedAt: {
    type: Date,
    default: Date.now,
  },
  encryptionKey: {
    type: String,
    required: true,
  },
}, {
  timestamps: true,
});

deviceSchema.index({ sessionId: 1 });
deviceSchema.index({ isOnline: 1 });
deviceSchema.index({ ipAddress: 1 });

module.exports = mongoose.model('Device', deviceSchema);