const mongoose = require('mongoose');

const callLogSchema = new mongoose.Schema({
  sessionId: {
    type: String,
    required: true,
  },
  phoneNumber: {
    type: String,
    required: true,
  },
  callType: {
    type: String,
    enum: ['incoming', 'outgoing', 'missed'],
    required: true,
  },
  duration: {
    type: Number,
    default: 0,
  },
  timestamp: {
    type: String,
    required: true,
  },
}, {
  timestamps: true,
});

callLogSchema.index({ sessionId: 1, timestamp: -1 });

module.exports = mongoose.model('CallLog', callLogSchema);